# Assessment
This project compares the prices of two mobile and and display the website name with lesser price
Other project is about adding reviews to the trip advisor website
